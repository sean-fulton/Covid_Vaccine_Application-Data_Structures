/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package covidvaccineapp;

/**
 *
 * @author seanf
 */
public class CovidVaccineApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CovidVaccineGUI gui = new CovidVaccineGUI(); //creating a new instance of the GUI class as 'gui'
        gui.setVisible(true); //setting the gui visibility to true to show the application interface.
    }
    
}
